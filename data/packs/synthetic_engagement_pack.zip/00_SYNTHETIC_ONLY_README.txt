SYNTHETIC ENGAGEMENT PACK — NOT REAL CLIENT DATA
================================================
This ZIP is for smoke tests and demos only.
Drop your anonymized real pack beside this file in data/packs/
(e.g. my_engagement_anonymized.zip), then use “Load pack” in Consulting Desk
or upload via drag-and-drop.
